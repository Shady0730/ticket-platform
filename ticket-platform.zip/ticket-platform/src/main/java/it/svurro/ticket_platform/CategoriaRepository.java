package it.svurro.ticket_platform;

public class CategoriaRepository {

}
