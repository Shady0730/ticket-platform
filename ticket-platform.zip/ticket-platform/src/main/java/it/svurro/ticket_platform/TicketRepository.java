package it.svurro.ticket_platform;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TicketRepository extends JpaRepository<Ticket, Long> {
    List<Ticket> findByTitoloContainingIgnoreCase(String titolo);
    List<Ticket> findByCategoria(Categoria categoria);
    List<Ticket> findByStato(StatoTicket stato);
    List<Ticket> findByOperatore(Operatore operatore);
    List<Ticket> findByTitoloContainingIgnoreCaseAndStato(String titolo, StatoTicket stato);
    List<Ticket> findByCategoriaAndStato(Categoria categoria, StatoTicket stato);
    List<Ticket> findByTitoloContainingIgnoreCaseOrDescrizioneContainingIgnoreCase(String titolo, String descrizione);
}
