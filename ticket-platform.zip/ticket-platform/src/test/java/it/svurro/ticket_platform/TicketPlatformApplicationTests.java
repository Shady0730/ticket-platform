package it.svurro.ticket_platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketPlatformApplicationTests {

    @Test
    void contextLoads() {
    }
    
}