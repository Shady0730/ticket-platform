package it.svurro.ticket_platform;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TicketService {

    @Autowired
    private TicketRepository ticketRepository;

    @Autowired
    private OperatoreRepository operatoreRepository;

    public List<Ticket> findAll() {
        return ticketRepository.findAll();
    }

    public Optional<Ticket> findById(Long id) {
        return ticketRepository.findById(id);
    }

    public Ticket save(Ticket ticket) {
        if (isValidTicket(ticket)) {
            return ticketRepository.save(ticket);
        } else {
            throw new IllegalArgumentException("Il ticket non è valido.");
        }
    }
    
    public void deleteById(Long id) {
        ticketRepository.deleteById(id);
    }

    public List<Ticket> searchTickets(String searchTerm) {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return findAll();
        } else {
            return ticketRepository.findByTitoloContainingIgnoreCaseOrDescrizioneContainingIgnoreCase(searchTerm, searchTerm);
        }
    }

    public Ticket updateStato(Long id, StatoTicket nuovoStato) {
        return ticketRepository.findById(id)
            .map(ticket -> {
                ticket.setStato(nuovoStato);
                return ticketRepository.save(ticket);
            })
            .orElse(null);
    }

    public void assignOperatoreToTicket(Long ticketId, Long operatoreId) {
        Optional<Ticket> ticketOptional = ticketRepository.findById(ticketId);
        Optional<Operatore> operatoreOptional = operatoreRepository.findById(operatoreId);

        if (ticketOptional.isPresent() && operatoreOptional.isPresent()) {
            Ticket ticket = ticketOptional.get();
            Operatore operatore = operatoreOptional.get();
            ticket.setOperatore(operatore);
            ticketRepository.save(ticket);
        }
    }

    public Ticket addNotaToTicket(Long ticketId, Nota nota) {
        return ticketRepository.findById(ticketId)
            .map(ticket -> {
                nota.setTicket(ticket);
                ticket.getNote().add(nota);
                return ticketRepository.save(ticket);
            })
            .orElse(null);
    }

    public void updateTicket(Long id, Ticket updatedTicket) {
        Optional<Ticket> existingTicketOpt = ticketRepository.findById(id);
        if (existingTicketOpt.isPresent()) {
            Ticket existingTicket = existingTicketOpt.get();
            existingTicket.setTitolo(updatedTicket.getTitolo());
            existingTicket.setDescrizione(updatedTicket.getDescrizione());
            existingTicket.setStato(updatedTicket.getStato());
            ticketRepository.save(existingTicket);
        }
    }

    public boolean isValidTicket(Ticket ticket) {
        return ticket.getTitolo() != null && !ticket.getTitolo().isEmpty() &&
               ticket.getDescrizione() != null && !ticket.getDescrizione().isEmpty() &&
               ticket.getStato() != null;
    }
}
