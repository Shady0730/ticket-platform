package it.svurro.ticket_platform;

public enum StatoTicket {
    DA_FARE,
    IN_CORSO,
    COMPLETATO
}