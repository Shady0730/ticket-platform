package it.svurro.ticket_platform;

public class OperatoreNonTrovato extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public OperatoreNonTrovato(String message) {
        super(message);
    }
}