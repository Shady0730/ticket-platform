package it.svurro.ticket_platform;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/notes")
public class NotaController {

    @Autowired
    private NotaService notaService;

    @GetMapping
    public List<Nota> getAllNotes() {
        return notaService.findAll();
    }

    @GetMapping("/{id}")
    public Optional<Nota> getNoteById(@PathVariable Long id) {
        return notaService.findById(id);
    }

    @PostMapping
    public Nota createNote(@RequestBody Nota nota) {
        return notaService.save(nota);
    }

    @PutMapping("/{id}")
    public Nota updateNote(@PathVariable Long id, @RequestBody Nota nota) {
        nota.setId(id);
        return notaService.save(nota);
    }

    @DeleteMapping("/{id}")
    public void deleteNote(@PathVariable Long id) {
        notaService.deleteById(id);
    }
}
