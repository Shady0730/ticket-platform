package it.svurro.ticket_platform;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/tickets")
public class TicketController {

    @Autowired
    private TicketService ticketService;

    @Autowired
    private OperatoreService operatoreService;

    @GetMapping("/search")
    public String searchTickets(@RequestParam("search") String search, Model model) {
        List<Ticket> tickets = ticketService.searchTickets(search);
        model.addAttribute("tickets", tickets);
        model.addAttribute("search", search);
        return "adminDashboard";
    }

    @GetMapping("/{id}/edit")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        Optional<Ticket> optionalTicket = ticketService.findById(id);
        optionalTicket.ifPresent(ticket -> model.addAttribute("ticket", ticket));
        return "edit-ticket";
    }

    @PostMapping("/{id}/edit")
    public String updateTicket(@PathVariable("id") Long id, @ModelAttribute Ticket updatedTicket) {
        ticketService.updateTicket(id, updatedTicket);
        return "redirect:/tickets";
    }

    @GetMapping("/{id}")
    public String getTicketDetails(@PathVariable("id") Long id, Model model) {
        Ticket ticket = ticketService.findById(id).orElse(null);
        model.addAttribute("ticket", ticket);
        return "adminDetailTicket";
    }

    @PostMapping("/{id}/add-note")
    public String addNote(@PathVariable("id") Long id, @RequestParam("nota") String notaTesto) {
        Optional<Ticket> optionalTicket = ticketService.findById(id);
        optionalTicket.ifPresent(ticket -> {
            Nota nota = new Nota();
            nota.setTesto(notaTesto);
            nota.setAutore("Autore");
            nota.setDataCreazione(LocalDateTime.now());
            ticketService.addNotaToTicket(id, nota);
        });
        return "redirect:/tickets/" + id;
    }

    @GetMapping("/{id}/assign")
    public String showAssignOperatorForm(@PathVariable("id") Long id, Model model) {
        Optional<Ticket> optionalTicket = ticketService.findById(id);
        if (optionalTicket.isPresent()) {
            List<Operatore> operatori = operatoreService.findAll();
            model.addAttribute("ticket", optionalTicket.get());
            model.addAttribute("operatori", operatori);
            return "assegnaOperatore";
        }
		return null;
    }

    @PostMapping("/{ticketId}/assign")
    public String assignOperatorToTicket(@PathVariable("ticketId") Long ticketId, @RequestParam("operatoreId") Long operatoreId) {
        ticketService.assignOperatoreToTicket(ticketId, operatoreId);
        return "redirect:/tickets";
    }

    @GetMapping("/new")
    public String createTicket(@ModelAttribute Ticket ticket, Model model) {
        if (ticketService.isValidTicket(ticket)) {
            ticketService.save(ticket);
            return "redirect:/tickets";
        }
        return "nuovoTicket";
    }

    @PostMapping("/{id}/delete")
    public void deleteTicket(@PathVariable("id") Long id) {
        ticketService.deleteById(id);
        return;
    }
}
