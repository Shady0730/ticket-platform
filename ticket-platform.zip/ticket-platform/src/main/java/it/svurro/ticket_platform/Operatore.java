package it.svurro.ticket_platform;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;


import java.util.Set;

@Entity
public class Operatore{


	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;

    private String email;

    private String password;

    private Boolean statoDisponibile;

    private String role; 

    @OneToMany(mappedBy = "operatore")
    private Set<Ticket> ticketAssegnati;

    // Getter e Setter

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

  

    public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
        this.password = password;
    }

    public Boolean getStatoDisponibile() {
        return statoDisponibile;
    }

    public void setStatoDisponibile(Boolean statoDisponibile) {
        this.statoDisponibile = statoDisponibile;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

}