package it.svurro.ticket_platform;

public class TicketNonTrovato extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public TicketNonTrovato(String message) {
        super(message);
    }
}
