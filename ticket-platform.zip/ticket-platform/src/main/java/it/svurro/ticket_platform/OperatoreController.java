package it.svurro.ticket_platform;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/operator")
public class OperatoreController {

    @Autowired
    private TicketService ticketService;

    @Autowired
    private OperatoreService operatoreService;
    
    @GetMapping("/operatori")
    public String getListaOperatori(Model model) {
        List<Operatore> operatori = operatoreService.getAllOperatori();
        model.addAttribute("operatori", operatori);
        return "listaOperatori"; 
    }

    @GetMapping("/dashboard")
    public String getOperatoreDashboard(@RequestParam(value = "id", required = false) Long id, Model model) {
        if (id != null) {
            Operatore operatore = operatoreService.getOperatore(id); 
            model.addAttribute("operatore", operatore);
        }
        return "operatoreDashboard"; 
    }
    
    @GetMapping("/tickets/{id}")
    public String getTicketDetails(@PathVariable Long id, Model model) {
        Ticket ticket = ticketService.findById(id).orElse(null);
        model.addAttribute("ticket", ticket);
        return "ticket-details";
    }

    @PostMapping("/tickets/{id}/update-status")
    public String updateTicketStatus(@PathVariable Long id, @RequestParam StatoTicket nuovoStato) {
        ticketService.updateStato(id, nuovoStato);
        return "redirect:/operator/tickets/" + id;
    }

    @PostMapping("/tickets/{id}/add-note")
    public String addNoteToTicket(@PathVariable Long id, @ModelAttribute Nota nota) {
        ticketService.addNotaToTicket(id, nota);
        return "redirect:/operator/tickets/" + id;
    }

    @PostMapping("/update")
    public String updateOperatore(@ModelAttribute Operatore operatore) {
        operatoreService.updateOperatore(operatore);
        return "redirect:/operator/dashboard?id=" + operatore.getId();
    }
}
