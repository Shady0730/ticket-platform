package it.svurro.ticket_platform;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private TicketService ticketService;

    @GetMapping("/dashboard")
    public String getDashboard(Model model) {
        List<Ticket> tickets = ticketService.findAll();
        model.addAttribute("tickets", tickets);
        return "adminDashboard";
    }

    @GetMapping("/tickets/{id}")
    public String getTicketDetails(@PathVariable Long id, Model model) {
        Ticket ticket = ticketService.findById(id).orElse(null);
        model.addAttribute("ticket", ticket);
        return "adminDetailTicket";
    }   

    @PostMapping("/tickets/{id}/add-note")
    public String addNoteToTicket(@PathVariable Long id, @ModelAttribute Nota nota) {
        ticketService.addNotaToTicket(id, nota);
        return "redirect:/admin/tickets/" + id;
    }
}