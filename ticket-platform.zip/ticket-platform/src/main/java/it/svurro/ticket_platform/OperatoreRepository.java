package it.svurro.ticket_platform;

import org.springframework.data.jpa.repository.JpaRepository;

public interface OperatoreRepository extends JpaRepository<Operatore, Long> {
}
