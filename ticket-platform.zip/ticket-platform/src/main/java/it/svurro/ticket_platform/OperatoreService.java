package it.svurro.ticket_platform;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OperatoreService {

    @Autowired
    private OperatoreRepository operatoreRepository;

    @Autowired
    private TicketRepository ticketRepository;

    public Optional<Operatore> findById(Long id) {
        return operatoreRepository.findById(id);
    }

    public void updateOperatore(Operatore operatore) {
        operatoreRepository.save(operatore);
    }

    public List<Ticket> getTicketsByOperatore(Operatore operatore) {
        return ticketRepository.findByOperatore(operatore);
    }
    
    public List<Operatore> findAll() {
        return operatoreRepository.findAll(); 
    }
    
    public List<Operatore> getAllOperatori() {
        return operatoreRepository.findAll();
    }
    
    public Operatore getOperatore(Long id) {
        return operatoreRepository.findById(id).orElse(null);
    }
}